# Changelog

| Chart version | App version | Change description |
| :------------ | :---------- | :----------------- |
| 0.1.0 | v3.5.6 | Initial version |
| 0.1.1 | v3.5.7 | Upgraded etcd to v3.5.7 |
| 0.1.2 | v3.5.7 | Updated default security context |
| 0.1.3 | v3.5.7 | Fixed "nil" syntax error for health checks (thx @omegazeng) |
| 0.1.4 | v3.5.8 | Upgraded etcd to v3.5.8 |
| 0.1.5 | v3.5.9 | Upgraded etcd to v3.5.9 |
| 0.1.6 | v3.5.9 | Added support for network policies and additional labels and annotations |
| 0.1.7 | v3.5.10 | Upgraded etcd to v3.5.10 |
| 0.1.8 | v3.5.11 | Upgraded etcd to v3.5.11 |
| 0.1.9 | v3.5.12 | Upgraded etcd to v3.5.12 |
| 0.1.10 | v3.5.13 | Upgraded etcd to v3.5.13 |
| 0.1.11 | v3.5.13 | Fixed build pipeline issue |
| 1.0.0 | v3.5.13 | Final version with configuration secret, extra config and extra volume support |
| 1.0.1 | v3.5.15 | Upgraded etcd to v3.5.15 |
| 1.0.2 | v3.5.16 | Upgraded etcd to v3.5.16 |
| 1.0.3 | v3.5.17 | Upgraded etcd to v3.5.17 |
| 1.0.4 | v3.5.18 | Upgraded etcd to v3.5.18 |
| 1.0.6 | v3.5.20 | Upgraded etcd to v3.5.20 |
| 1.0.7 | v3.5.21 | Upgraded etcd to v3.5.21 |
| 1.0.8 | v3.5.21 | Added support for loadBalancerSourceRanges |
| 1.1.0 | v3.6.4 | Upgraded etcd to v3.6.4 |
| 1.1.1 | v3.6.4 | Changed to busybox:stable containter image |
| 1.1.2 | v3.6.4 | Added ability to set automountServiceAccountToken - thx @krizzpiBiGdirekt |
| 1.1.3 | v3.6.4 | Added priorityClassName - thx @JimCronqvist |
| 1.1.4 | v3.6.6 | Upgraded etcd to v3.6.6 |
| 1.1.5 | v3.6.7 | Upgraded etcd to v3.6.7 |
| 1.1.6 | v3.6.9 | Upgraded etcd to v3.6.9 |
| 1.1.7 | v3.6.9 | Fixed insecure parameters - thx @oleksiialeksieiev |
| 1.1.8 | v3.6.11 | Upgraded etcd to v3.6.11 |
| 1.1.9 | v3.6.13 | Upgraded etcd to v3.6.13, fixed PVC definition - thx @trandbert37 |
| 1.1.10 | v3.7.0 | Upgraded etcd to v3.7.0 |
| 1.1.11 | v3.7.0 | Fixed README.md markdown formatting |
| 1.1.12 | v3.7.1 | Upgraded etcd to v3.7.1 |
| 1.1.13 | v3.7.1 | Added settings.advertiseClientUrls to advertise additional client URLs (f.e. for access from outside of Kubernetes) |
| 1.1.14 | v3.7.2 | Upgraded etcd to v3.7.2 |
| 1.1.15 | v3.7.3 | Upgraded etcd to v3.7.3 |
| 1.1.16 | v3.7.4 | Upgraded etcd to v3.7.4 |
| | | |
